import { SplineBackground } from "@/components/ui/spline-background";

export function HeroSection() {
  return (
    <section className="relative w-full min-h-screen">
      <SplineBackground 
        title="Intelligent Automation" 
        description="Streamline · Automate · Transform"
      />
    </section>
  );
}