import { motion, useAnimationControls } from "framer-motion";
import { useEffect, useState } from "react";
import Spline from "@splinetool/react-spline";

interface SplineBackgroundProps {
  title: string;
  description: string;
}

export function SplineBackground({ title, description }: SplineBackgroundProps) {
  const [displayedText, setDisplayedText] = useState("");
  const controls = useAnimationControls();
  
  useEffect(() => {
    let currentText = "";
    const typeText = async () => {
      for (let i = 0; i <= title.length; i++) {
        currentText = title.slice(0, i);
        setDisplayedText(currentText);
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      // Start cursor blink animation after typing
      controls.start({
        opacity: [1, 0],
        transition: {
          duration: 0.8,
          repeat: Infinity,
          repeatType: "reverse"
        }
      });
    };
    
    typeText();
  }, [title, controls]);

  return (
    <div className="relative w-full h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 z-0">
        <Spline scene="https://prod.spline.design/oo6IxFu8UZvHUmjD/scene.splinecode" />
      </div>
      
      <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
        <div className="flex items-center justify-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 uppercase tracking-wider"
          >
            {displayedText}
            <motion.span
              animate={controls}
              className="inline-block w-[4px] h-[1em] bg-white ml-1 align-middle"
            />
          </motion.h1>
        </div>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-lg sm:text-xl md:text-2xl text-slate-400 max-w-2xl mx-auto uppercase tracking-[0.2em]"
        >
          {description}
        </motion.p>
      </div>
    </div>
  );
}