import { motion } from "framer-motion";
import { ContactForm } from "@/components/contact-form";

export function CTASection() {
  return (
    <section id="contact" className="py-24 relative bg-slate-900">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-30 bg-[radial-gradient(circle_at_30%_20%,rgba(59,130,246,0.2),transparent_40%),radial-gradient(circle_at_70%_60%,rgba(56,189,248,0.2),transparent_40%)]"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-8 md:p-12 border border-slate-700/50 shadow-xl">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-8"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Ready to Transform Your Business with AI?
            </h2>
            <p className="text-slate-300 text-lg max-w-2xl mx-auto">
              Schedule a free discovery call to discuss how our AI solutions can help you automate workflows, engage customers, and drive growth.
            </p>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="flex flex-col items-center justify-center"
          >
            <div className="mb-4">
              <ContactForm />
            </div>
            <p className="text-slate-400 text-sm mt-4">
              No commitment required. Learn how we can tailor our solutions for your business.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}