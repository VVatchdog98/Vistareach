import { motion } from "framer-motion";
import { Workflow, Zap, RefreshCw, Clock, Shield, Settings } from "lucide-react";
import { ContactForm } from "@/components/contact-form";

const features = [
  {
    icon: <Workflow className="w-6 h-6" />,
    title: "Smart Workflow Design",
    description: "AI-powered workflow creation that adapts to your business processes and optimizes for efficiency."
  },
  {
    icon: <Zap className="w-6 h-6" />,
    title: "Instant Automation",
    description: "Immediate execution of repetitive tasks, reducing manual work and increasing productivity."
  },
  {
    icon: <RefreshCw className="w-6 h-6" />,
    title: "Continuous Optimization",
    description: "Self-improving workflows that learn from patterns and optimize for better performance."
  },
  {
    icon: <Clock className="w-6 h-6" />,
    title: "Time-Based Triggers",
    description: "Schedule-based automation ensuring tasks are executed at the right time, every time."
  },
  {
    icon: <Shield className="w-6 h-6" />,
    title: "Secure Processing",
    description: "Enterprise-grade security ensuring your automated processes remain protected and compliant."
  },
  {
    icon: <Settings className="w-6 h-6" />,
    title: "Custom Integration",
    description: "Seamless integration with your existing tools and systems for unified automation."
  }
];

export function WorkflowAutomationPage() {
  return (
    <div className="bg-slate-950 min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6 font-mono">
              Workflow Automation
            </h1>
            <p className="text-xl text-slate-300 mb-8 font-mono">
              Streamline your business processes with intelligent automation that saves time and reduces errors.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-slate-900 border border-slate-800 rounded-xl p-8 mb-12"
          >
            <h2 className="text-2xl font-bold text-white mb-4 font-mono">Automation Features</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index }}
                  className="flex gap-4"
                >
                  <div className="flex-shrink-0 w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center text-blue-400">
                    {feature.icon}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-2 font-mono">{feature.title}</h3>
                    <p className="text-slate-400 font-mono">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-slate-900 border border-slate-800 rounded-xl p-8"
          >
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-white mb-4 font-mono">Automate Your Business Today</h2>
              <p className="text-slate-400 font-mono">
                Schedule a consultation to see how our workflow automation can transform your operations.
              </p>
            </div>
            <ContactForm />
          </motion.div>
        </div>
      </div>
    </div>
  );
}