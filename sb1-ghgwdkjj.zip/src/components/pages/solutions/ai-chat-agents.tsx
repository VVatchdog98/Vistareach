import { motion } from "framer-motion";
import { MessageSquare, Bot, Zap, BarChart3, Shield, Cpu } from "lucide-react";
import { ContactForm } from "@/components/contact-form";

const features = [
  {
    icon: <Bot className="w-6 h-6" />,
    title: "Natural Language Understanding",
    description: "Advanced AI that understands context, intent, and nuanced customer queries with human-like comprehension."
  },
  {
    icon: <Zap className="w-6 h-6" />,
    title: "24/7 Availability",
    description: "Always-on customer service that handles inquiries instantly, reducing wait times and improving satisfaction."
  },
  {
    icon: <BarChart3 className="w-6 h-6" />,
    title: "Analytics & Insights",
    description: "Detailed analytics on customer interactions, common queries, and satisfaction metrics for continuous improvement."
  },
  {
    icon: <Shield className="w-6 h-6" />,
    title: "Secure Conversations",
    description: "Enterprise-grade security ensuring all customer interactions and data remain private and protected."
  },
  {
    icon: <MessageSquare className="w-6 h-6" />,
    title: "Multi-Channel Support",
    description: "Seamless integration across website, mobile apps, and messaging platforms for consistent support."
  },
  {
    icon: <Cpu className="w-6 h-6" />,
    title: "Continuous Learning",
    description: "AI that learns from each interaction to provide increasingly accurate and helpful responses."
  }
];

export function AIChatAgentsPage() {
  return (
    <div className="bg-slate-950 min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6 font-mono">
              AI Chat Agents
            </h1>
            <p className="text-xl text-slate-300 mb-8 font-mono">
              Transform your customer service with intelligent AI chat agents that provide instant, accurate responses 24/7.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-slate-900 border border-slate-800 rounded-xl p-8 mb-12"
          >
            <h2 className="text-2xl font-bold text-white mb-4 font-mono">Why Choose Our AI Chat Agents?</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index }}
                  className="flex gap-4"
                >
                  <div className="flex-shrink-0 w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center text-blue-400">
                    {feature.icon}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-2 font-mono">{feature.title}</h3>
                    <p className="text-slate-400 font-mono">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-slate-900 border border-slate-800 rounded-xl p-8"
          >
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-white mb-4 font-mono">Ready to Transform Your Customer Service?</h2>
              <p className="text-slate-400 font-mono">
                Book a demo to see our AI chat agents in action and discuss your specific needs.
              </p>
            </div>
            <ContactForm />
          </motion.div>
        </div>
      </div>
    </div>
  );
}