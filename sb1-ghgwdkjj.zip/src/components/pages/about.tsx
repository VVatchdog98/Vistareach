import { motion } from "framer-motion";

export function AboutPage() {
  return (
    <div className="bg-slate-950 min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-8 font-mono">
            About Vistareach.AI
          </h1>
          
          <div className="prose prose-invert max-w-none">
            <p className="text-xl text-slate-300 mb-8 font-mono">
              Vistareach.AI is at the forefront of AI-powered business transformation, 
              specializing in intelligent automation solutions that drive growth and 
              efficiency for forward-thinking companies.
            </p>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 mb-12">
              <h2 className="text-2xl font-bold text-white mb-4 font-mono">Our Mission</h2>
              <p className="text-slate-300 font-mono">
                To empower businesses with cutting-edge AI solutions that transform 
                customer interactions, streamline operations, and accelerate growth 
                in the digital age.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
                <h3 className="text-xl font-bold text-white mb-3 font-mono">Innovation</h3>
                <p className="text-slate-300 font-mono">
                  We continuously push the boundaries of what's possible with AI, 
                  developing solutions that adapt and evolve with your business needs.
                </p>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
                <h3 className="text-xl font-bold text-white mb-3 font-mono">Expertise</h3>
                <p className="text-slate-300 font-mono">
                  Our team combines deep technical knowledge with business acumen 
                  to deliver solutions that drive real-world results.
                </p>
              </div>
            </div>

            <h2 className="text-2xl font-bold text-white mb-6 font-mono">Why Choose Vistareach.AI?</h2>
            <ul className="space-y-4 text-slate-300 font-mono">
              <li>• Cutting-edge AI technology customized for your business needs</li>
              <li>• Proven track record of delivering measurable ROI</li>
              <li>• Dedicated support team available 24/7</li>
              <li>• Seamless integration with existing systems</li>
              <li>• Continuous optimization and improvement</li>
            </ul>
          </div>
        </motion.div>
      </div>
    </div>
  );
}