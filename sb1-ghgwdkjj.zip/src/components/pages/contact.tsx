import { motion } from "framer-motion";
import { Mail, Phone, MapPin, Clock } from "lucide-react";
import { ContactForm } from "@/components/contact-form";

export function ContactPage() {
  return (
    <div className="bg-slate-950 min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6 font-mono">
              Get in Touch
            </h1>
            <p className="text-slate-400 text-lg max-w-2xl mx-auto font-mono">
              Ready to transform your business with AI? We're here to help you get started.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-8">
                <h2 className="text-2xl font-bold text-white mb-6 font-mono">Contact Information</h2>
                
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <Mail className="w-6 h-6 text-blue-400 mt-1" />
                    <div>
                      <p className="text-white font-medium mb-1 font-mono">Email</p>
                      <a href="mailto:deniel.mihaylov@outlook.com" className="text-slate-400 hover:text-blue-400 transition-colors font-mono">
                        deniel.mihaylov@outlook.com
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <Phone className="w-6 h-6 text-blue-400 mt-1" />
                    <div>
                      <p className="text-white font-medium mb-1 font-mono">Phone</p>
                      <p className="text-slate-400 font-mono">+1 (555) 123-4567</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <MapPin className="w-6 h-6 text-blue-400 mt-1" />
                    <div>
                      <p className="text-white font-medium mb-1 font-mono">Location</p>
                      <p className="text-slate-400 font-mono">
                        123 AI Innovation Center<br />
                        Silicon Valley, CA 94025
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <Clock className="w-6 h-6 text-blue-400 mt-1" />
                    <div>
                      <p className="text-white font-medium mb-1 font-mono">Business Hours</p>
                      <p className="text-slate-400 font-mono">
                        Monday - Friday: 9:00 AM - 6:00 PM PST<br />
                        Weekend: By appointment
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-8">
                <h2 className="text-2xl font-bold text-white mb-6 font-mono">Send us a Message</h2>
                <ContactForm />
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}