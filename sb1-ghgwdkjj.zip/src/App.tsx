import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Toaster } from "sonner";
import { Header } from "@/components/header";
import { HomePage } from "@/components/pages/home";
import { BlogPage } from "@/components/pages/blog";
import { AboutPage } from "@/components/pages/about";
import { ContactPage } from "@/components/pages/contact";
import { AIChatAgentsPage } from "@/components/pages/solutions/ai-chat-agents";
import { CRMIntegrationPage } from "@/components/pages/solutions/crm-integration";
import { LeadGenerationPage } from "@/components/pages/solutions/lead-generation";
import { WorkflowAutomationPage } from "@/components/pages/solutions/workflow-automation";
import { Footer } from "@/components/footer";

function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/solutions/ai-chat-agents" element={<AIChatAgentsPage />} />
        <Route path="/solutions/crm-integration" element={<CRMIntegrationPage />} />
        <Route path="/solutions/lead-generation" element={<LeadGenerationPage />} />
        <Route path="/solutions/workflow-automation" element={<WorkflowAutomationPage />} />
      </Routes>
      <Footer />
      <Toaster position="top-right" />
    </Router>
  );
}

export default App;