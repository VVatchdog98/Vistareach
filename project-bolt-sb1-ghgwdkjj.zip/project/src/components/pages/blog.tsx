import { motion } from "framer-motion";

const blogPosts = [
  {
    title: "The Future of AI in Business Growth",
    date: "March 15, 2025",
    excerpt: "Discover how AI is revolutionizing business growth strategies and what it means for your company's future.",
    image: "https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg",
    readTime: "5 min read"
  },
  {
    title: "Maximizing ROI with AI-Powered Lead Generation",
    date: "March 10, 2025",
    excerpt: "Learn how businesses are achieving unprecedented ROI through AI-driven lead generation and qualification systems.",
    image: "https://images.pexels.com/photos/7567444/pexels-photo-7567444.jpeg",
    readTime: "4 min read"
  },
  {
    title: "The Evolution of Customer Service with AI Chatbots",
    date: "March 5, 2025",
    excerpt: "Explore how AI chatbots are transforming customer service and creating 24/7 support experiences.",
    image: "https://images.pexels.com/photos/8353841/pexels-photo-8353841.jpeg",
    readTime: "6 min read"
  }
];

export function BlogPage() {
  return (
    <div className="bg-slate-950 min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6 font-mono">
            Latest Insights
          </h1>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto font-mono">
            Explore our latest thoughts on AI technology, business growth, and innovation
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <motion.article
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-slate-900 rounded-xl overflow-hidden border border-slate-800 hover:border-slate-700 transition-all duration-300"
            >
              <img 
                src={post.image} 
                alt={post.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center justify-between text-sm text-slate-400 mb-3 font-mono">
                  <span>{post.date}</span>
                  <span>{post.readTime}</span>
                </div>
                <h2 className="text-xl font-bold text-white mb-3 font-mono">{post.title}</h2>
                <p className="text-slate-400 mb-4 font-mono">{post.excerpt}</p>
                <button className="text-blue-400 hover:text-blue-300 font-medium font-mono">
                  Read More →
                </button>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </div>
  );
}