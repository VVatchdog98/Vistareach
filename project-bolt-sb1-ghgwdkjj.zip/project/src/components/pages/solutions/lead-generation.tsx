import { motion } from "framer-motion";
import { Target, Filter, UserCheck, Sparkles, BarChart3, Zap } from "lucide-react";
import { ContactForm } from "@/components/contact-form";

const features = [
  {
    icon: <Target className="w-6 h-6" />,
    title: "Smart Lead Targeting",
    description: "AI-powered algorithms identify and target high-potential leads based on behavior patterns and demographics."
  },
  {
    icon: <Filter className="w-6 h-6" />,
    title: "Automated Qualification",
    description: "Intelligent lead scoring and qualification to prioritize the most promising opportunities."
  },
  {
    icon: <UserCheck className="w-6 h-6" />,
    title: "Personalized Engagement",
    description: "Tailored communication strategies for each lead based on their interests and behavior."
  },
  {
    icon: <Sparkles className="w-6 h-6" />,
    title: "Multi-Channel Capture",
    description: "Capture leads across various channels including social media, website, and email campaigns."
  },
  {
    icon: <BarChart3 className="w-6 h-6" />,
    title: "Performance Analytics",
    description: "Comprehensive analytics dashboard tracking lead quality, conversion rates, and ROI."
  },
  {
    icon: <Zap className="w-6 h-6" />,
    title: "Instant Follow-up",
    description: "Automated follow-up sequences ensuring no lead goes uncontacted."
  }
];

export function LeadGenerationPage() {
  return (
    <div className="bg-slate-950 min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6 font-mono">
              Lead Generation
            </h1>
            <p className="text-xl text-slate-300 mb-8 font-mono">
              Generate and qualify high-quality leads automatically with our AI-powered lead generation system.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-slate-900 border border-slate-800 rounded-xl p-8 mb-12"
          >
            <h2 className="text-2xl font-bold text-white mb-4 font-mono">Key Features</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index }}
                  className="flex gap-4"
                >
                  <div className="flex-shrink-0 w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center text-blue-400">
                    {feature.icon}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-2 font-mono">{feature.title}</h3>
                    <p className="text-slate-400 font-mono">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-slate-900 border border-slate-800 rounded-xl p-8"
          >
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-white mb-4 font-mono">Start Generating Better Leads</h2>
              <p className="text-slate-400 font-mono">
                Book a demo to see how our AI-powered lead generation can accelerate your business growth.
              </p>
            </div>
            <ContactForm />
          </motion.div>
        </div>
      </div>
    </div>
  );
}