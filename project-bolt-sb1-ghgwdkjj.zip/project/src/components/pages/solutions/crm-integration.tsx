import { motion } from "framer-motion";
import { Database, RefreshCw, Workflow, Users, LineChart, Lock } from "lucide-react";
import { ContactForm } from "@/components/contact-form";

const features = [
  {
    icon: <Database className="w-6 h-6" />,
    title: "Seamless Data Integration",
    description: "Automatic synchronization with popular CRM platforms ensuring your customer data is always up-to-date."
  },
  {
    icon: <RefreshCw className="w-6 h-6" />,
    title: "Real-Time Updates",
    description: "Instant data updates across all systems, maintaining consistency and accuracy in customer information."
  },
  {
    icon: <Workflow className="w-6 h-6" />,
    title: "Automated Workflows",
    description: "Smart automation of repetitive tasks, freeing your team to focus on high-value activities."
  },
  {
    icon: <Users className="w-6 h-6" />,
    title: "360° Customer View",
    description: "Comprehensive customer profiles combining data from all touchpoints for better decision-making."
  },
  {
    icon: <LineChart className="w-6 h-6" />,
    title: "Advanced Analytics",
    description: "Detailed insights into customer behavior, engagement patterns, and business performance."
  },
  {
    icon: <Lock className="w-6 h-6" />,
    title: "Secure Integration",
    description: "Enterprise-grade security ensuring your customer data remains protected during integration."
  }
];

export function CRMIntegrationPage() {
  return (
    <div className="bg-slate-950 min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6 font-mono">
              CRM Integration
            </h1>
            <p className="text-xl text-slate-300 mb-8 font-mono">
              Supercharge your CRM with AI-powered automation and insights for enhanced customer relationships.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-slate-900 border border-slate-800 rounded-xl p-8 mb-12"
          >
            <h2 className="text-2xl font-bold text-white mb-4 font-mono">Features & Benefits</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index }}
                  className="flex gap-4"
                >
                  <div className="flex-shrink-0 w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center text-blue-400">
                    {feature.icon}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-2 font-mono">{feature.title}</h3>
                    <p className="text-slate-400 font-mono">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-slate-900 border border-slate-800 rounded-xl p-8"
          >
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-white mb-4 font-mono">Enhance Your CRM Today</h2>
              <p className="text-slate-400 font-mono">
                Schedule a consultation to see how our AI-powered CRM integration can transform your business.
              </p>
            </div>
            <ContactForm />
          </motion.div>
        </div>
      </div>
    </div>
  );
}