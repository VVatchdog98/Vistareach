"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, ChevronDown } from "lucide-react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ContactForm } from "@/components/contact-form";

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSolutionsOpen, setIsSolutionsOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const solutions = [
    { name: "AI Chat Agents", href: "/solutions/ai-chat-agents" },
    { name: "CRM Integration", href: "/solutions/crm-integration" },
    { name: "Lead Generation", href: "/solutions/lead-generation" },
    { name: "Workflow Automation", href: "/solutions/workflow-automation" },
  ];

  const navItems = [
    { name: "Blog", href: "/blog" },
    { name: "About", href: "/about" },
    { name: "Contact", href: "/contact" },
  ];

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-40 transition-all duration-300",
        isScrolled 
          ? "bg-slate-950/90 backdrop-blur-lg py-3 shadow-lg" 
          : "bg-transparent py-5"
      )}
    >
      <div className="container mx-auto px-4 flex items-center justify-between">
        <Link to="/">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-white font-bold text-2xl font-mono"
          >
            Vistareach<span className="text-blue-400">.AI</span>
          </motion.div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-1">
          <ul className="flex space-x-1">
            <li className="relative">
              <button
                onClick={() => setIsSolutionsOpen(!isSolutionsOpen)}
                className="px-4 py-2 text-slate-300 hover:text-white rounded-md transition-colors duration-200 font-mono flex items-center gap-1"
              >
                Solutions <ChevronDown className="w-4 h-4" />
              </button>
              {isSolutionsOpen && (
                <div className="absolute top-full left-0 mt-2 w-64 bg-slate-900 rounded-lg shadow-lg border border-slate-800 py-2">
                  {solutions.map((solution) => (
                    <Link
                      key={solution.name}
                      to={solution.href}
                      className="block px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors duration-200 font-mono"
                      onClick={() => setIsSolutionsOpen(false)}
                    >
                      {solution.name}
                    </Link>
                  ))}
                </div>
              )}
            </li>
            {navItems.map((item) => (
              <li key={item.name}>
                <Link
                  to={item.href}
                  className="px-4 py-2 text-slate-300 hover:text-white rounded-md transition-colors duration-200 font-mono"
                >
                  {item.name}
                </Link>
              </li>
            ))}
          </ul>
          <div className="ml-4">
            <ContactForm />
          </div>
        </nav>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-white p-2"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-slate-900 overflow-hidden"
          >
            <div className="container mx-auto px-4 py-4">
              <ul className="flex flex-col space-y-3">
                <li>
                  <button
                    onClick={() => setIsSolutionsOpen(!isSolutionsOpen)}
                    className="w-full text-left px-4 py-2 text-slate-300 hover:text-white rounded-md transition-colors duration-200 font-mono flex items-center justify-between"
                  >
                    Solutions <ChevronDown className="w-4 h-4" />
                  </button>
                  {isSolutionsOpen && (
                    <div className="pl-4 mt-2 space-y-2">
                      {solutions.map((solution) => (
                        <Link
                          key={solution.name}
                          to={solution.href}
                          className="block px-4 py-2 text-slate-300 hover:text-white transition-colors duration-200 font-mono"
                          onClick={() => {
                            setIsSolutionsOpen(false);
                            setIsMobileMenuOpen(false);
                          }}
                        >
                          {solution.name}
                        </Link>
                      ))}
                    </div>
                  )}
                </li>
                {navItems.map((item) => (
                  <li key={item.name}>
                    <Link
                      to={item.href}
                      className="block px-4 py-2 text-slate-300 hover:text-white rounded-md transition-colors duration-200 font-mono"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      {item.name}
                    </Link>
                  </li>
                ))}
                <li className="pt-2">
                  <div className="px-4">
                    <ContactForm />
                  </div>
                </li>
              </ul>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}