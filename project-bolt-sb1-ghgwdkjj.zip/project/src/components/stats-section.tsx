import { motion } from "framer-motion";
import { 
  TrendingUp, 
  Clock, 
  Percent, 
  Users 
} from "lucide-react";

const stats = [
  {
    icon: <TrendingUp className="h-6 w-6" />,
    value: "300%",
    label: "Average ROI",
    description: "Return on AI investment",
  },
  {
    icon: <Clock className="h-6 w-6" />,
    value: "65%",
    label: "Time Saved",
    description: "On customer service tasks",
  },
  {
    icon: <Percent className="h-6 w-6" />,
    value: "42%",
    label: "Conversion Increase",
    description: "From AI-qualified leads",
  },
  {
    icon: <Users className="h-6 w-6" />,
    value: "24/7",
    label: "Customer Support",
    description: "Without human intervention",
  },
];

export function StatsSection() {
  return (
    <section className="py-24 relative bg-gradient-to-b from-slate-950 to-slate-900">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ 
                duration: 0.5, 
                delay: index * 0.1 
              }}
              className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-8 backdrop-blur-sm"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20">
                  {stat.icon}
                </div>
                <h3 className="text-white font-medium">{stat.label}</h3>
              </div>
              <div className="mb-2 text-4xl md:text-5xl font-bold text-white">
                {stat.value}
              </div>
              <p className="text-slate-400">
                {stat.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}