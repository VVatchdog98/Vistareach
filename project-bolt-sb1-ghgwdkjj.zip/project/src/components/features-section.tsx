import { motion } from "framer-motion";
import { 
  MessageSquare, 
  BarChart3, 
  Users, 
  Zap,
  Bot,
  Briefcase,
  LineChart,
  ArrowUpRight
} from "lucide-react";
import { cn } from "@/lib/utils";

const features = [
  {
    icon: <MessageSquare className="h-6 w-6" />,
    title: "AI Chat Agents",
    description: "24/7 intelligent conversational agents that engage leads and customers with human-like interactions.",
    color: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  },
  {
    icon: <Bot className="h-6 w-6" />,
    title: "Custom AI Assistants",
    description: "Tailor-made AI solutions that understand your business and deliver personalized experiences.",
    color: "bg-cyan-500/10 text-cyan-500 border-cyan-500/20",
  },
  {
    icon: <Briefcase className="h-6 w-6" />,
    title: "CRM Integration",
    description: "Seamless integration with your existing CRM platforms to automate workflow and enhance customer data.",
    color: "bg-indigo-500/10 text-indigo-500 border-indigo-500/20",
  },
  {
    icon: <Users className="h-6 w-6" />,
    title: "Lead Generation",
    description: "Advanced lead capture and qualification systems that deliver high-quality prospects.",
    color: "bg-purple-500/10 text-purple-500 border-purple-500/20",
  },
  {
    icon: <LineChart className="h-6 w-6" />,
    title: "Performance Analytics",
    description: "Comprehensive dashboards and insights to track ROI and optimize your AI investments.",
    color: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
  },
  {
    icon: <Zap className="h-6 w-6" />,
    title: "Workflow Automation",
    description: "Eliminate repetitive tasks with intelligent automation that scales with your business.",
    color: "bg-amber-500/10 text-amber-500 border-amber-500/20",
  }
];

export function FeaturesSection() {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  return (
    <section id="solutions" className="relative py-24 bg-slate-950">
      {/* Background decorative elements */}
      <div className="absolute top-0 inset-x-0 h-40 bg-gradient-to-b from-blue-900/10 to-transparent"></div>
      <div className="absolute bottom-0 inset-x-0 h-40 bg-gradient-to-t from-blue-900/10 to-transparent"></div>
      <div className="absolute inset-0 opacity-30 bg-[radial-gradient(circle_at_30%_20%,rgba(59,130,246,0.2),transparent_40%),radial-gradient(circle_at_70%_60%,rgba(56,189,248,0.2),transparent_40%)]"></div>

      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-blue-400 font-semibold mb-4"
          >
            AI SOLUTIONS FOR BUSINESS GROWTH
          </motion.p>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl md:text-5xl font-bold text-white mb-6"
          >
            Transform Your Business With Intelligent Automation
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-slate-300 text-lg"
          >
            Our AI solutions optimize your operations, enhance customer experiences, and drive measurable business results.
          </motion.p>
        </div>

        <motion.div 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {features.map((feature, index) => (
            <motion.div 
              key={index}
              variants={item}
              className="relative group"
            >
              <div className={cn(
                "relative h-full p-8 rounded-xl border backdrop-blur-sm transition-all duration-300",
                "bg-slate-900/60 border-slate-800/60 hover:bg-slate-800/60",
                "flex flex-col"
              )}>
                <div className={cn(
                  "inline-flex p-3 rounded-lg mb-5",
                  feature.color
                )}>
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">{feature.title}</h3>
                <p className="text-slate-300 mb-6 flex-grow">{feature.description}</p>
                <div className="group-hover:translate-x-1 transition-transform duration-300 text-blue-400 font-medium flex items-center gap-1">
                  Learn more <ArrowUpRight className="h-4 w-4" />
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}