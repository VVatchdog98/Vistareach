"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import clsx from "clsx";

interface SplineBackgroundProps {
  title?: string;
  description?: string;
  className?: string;
}

export function SplineBackground({
  title = "Imperial.AI",
  description = "Intelligent Automation for Business Growth",
  className,
}: SplineBackgroundProps) {
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    // Simulate loading delay for Spline viewer
    const timer = setTimeout(() => {
      setLoaded(true);
    }, 500);
    
    return () => clearTimeout(timer);
  }, []);

  return (
    <div
      className={clsx(
        "relative flex h-screen w-full items-center justify-center overflow-hidden",
        "bg-slate-950 dark:bg-slate-950",
        className
      )}
    >
      {/* Spline viewer container */}
      <div className="absolute inset-0 h-full w-full">
        {/* Script tag will be rendered by React as HTML */}
        <div dangerouslySetInnerHTML={{
          __html: `
            <script type="module" src="https://unpkg.com/@splinetool/viewer@1.9.82/build/spline-viewer.js"></script>
            <spline-viewer url="https://prod.spline.design/3QHkIpBciyOmFeo3/scene.splinecode"></spline-viewer>
          `
        }} />
      </div>

      {/* Gradient overlay for better text visibility */}
      <div className="absolute inset-0 bg-gradient-to-b from-slate-950/80 via-slate-950/30 to-slate-950/80 z-[1]"></div>

      {/* Content */}
      <motion.div
        className="relative z-10 text-center max-w-4xl px-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="mb-3 inline-flex items-center rounded-full border border-blue-400/30 bg-blue-500/10 px-3 py-1 text-sm font-medium text-blue-300"
        >
          Next-Generation AI Solutions
        </motion.div>

        <h1
          className={clsx(
            "text-5xl font-bold tracking-tight md:text-7xl",
            "bg-gradient-to-r from-blue-300 via-cyan-200 to-teal-300 bg-clip-text text-transparent",
            "drop-shadow-[0_0_32px_rgba(94,234,212,0.4)]"
          )}
        >
          {title}
        </h1>

        <motion.p
          className="mt-6 text-xl md:text-2xl text-slate-200 max-w-2xl mx-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          {description}
        </motion.p>

        <motion.div 
          className="mt-8 flex flex-col sm:flex-row gap-4 justify-center"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <button className="px-8 py-3 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium shadow-lg shadow-blue-500/20 hover:shadow-blue-500/40 transition-all duration-300">
            Explore Solutions
          </button>
          <button className="px-8 py-3 rounded-lg bg-white/10 backdrop-blur-sm text-white font-medium border border-white/20 hover:bg-white/20 transition-all duration-300">
            Watch Demo
          </button>
        </motion.div>
      </motion.div>
    </div>
  );
}