import { SplineBackground } from "@/components/ui/spline-background";

export function HeroSection() {
  return (
    <section className="relative w-full min-h-screen">
      <SplineBackground 
        title="AI That Grows Your Business" 
        description="Conversation Agents, CRM Automation, and Lead Generation Solutions Designed for Maximum ROI"
      />
    </section>
  );
}